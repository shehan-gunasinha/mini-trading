package com.trading.orderservice.config;

import org.infinispan.configuration.cache.CacheMode;
import org.infinispan.configuration.cache.Configuration;
import org.infinispan.configuration.cache.ConfigurationBuilder;
import org.infinispan.configuration.global.GlobalConfiguration;
import org.infinispan.configuration.global.GlobalConfigurationBuilder;
import org.infinispan.manager.DefaultCacheManager;
import org.infinispan.manager.EmbeddedCacheManager;
import org.infinispan.spring.embedded.provider.SpringEmbeddedCacheManager;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;


import javax.annotation.PostConstruct;
import java.util.concurrent.TimeUnit;

@EnableCaching
@org.springframework.context.annotation.Configuration
public class InfinispanCacheConfig {

    // Orders cache configuration
    @Value("${cache.orders.max-entries:1000}")
    private long ordersMaxEntries;

    @Value("${cache.orders.ttl-seconds:300}")
    private long ordersTtl;

    @Value("${cache.orders.max-idle-seconds:120}")
    private long ordersMaxIdle;

    // Orders list cache configuration
    @Value("${cache.orders-list.max-entries:100}")
    private long ordersListMaxEntries;

    @Value("${cache.orders-list.ttl-seconds:60}")
    private long ordersListTtl;

    @Value("${cache.orders-list.max-idle-seconds:30}")
    private long ordersListMaxIdle;

    // Cache statistics
    @Value("${cache.statistics.enabled:true}")
    private boolean statisticsEnabled;

    @PostConstruct
    public void validateConfig() {
        if (ordersMaxEntries <= 0) {
            throw new IllegalArgumentException("cache.orders.max-entries must be positive");
        }
        if (ordersTtl <= 0) {
            throw new IllegalArgumentException("cache.orders.ttl-seconds must be positive");
        }
        if (ordersMaxIdle <= 0) {
            throw new IllegalArgumentException("cache.orders.max-idle-seconds must be positive");
        }
        if (ordersListMaxEntries <= 0) {
            throw new IllegalArgumentException("cache.orders-list.max-entries must be positive");
        }
        if (ordersListTtl <= 0) {
            throw new IllegalArgumentException("cache.orders-list.ttl-seconds must be positive");
        }
        if (ordersListMaxIdle <= 0) {
            throw new IllegalArgumentException("cache.orders-list.max-idle-seconds must be positive");
        }
    }

    // Global Infinispan config
    @Bean
    public EmbeddedCacheManager embeddedCacheManager() {
        GlobalConfiguration globalConfig = new GlobalConfigurationBuilder()
                .nonClusteredDefault()
                .defaultCacheName("default")  // Set default cache name
                .build();

        // DEFAULT CACHE CONFIGURATION - This is required!
        Configuration defaultCache = new ConfigurationBuilder()
                .clustering()
                .cacheMode(CacheMode.LOCAL)
                .memory()
                .maxCount(500)  // Default size
                .expiration()
                .lifespan(300, TimeUnit.SECONDS)
                .maxIdle(120, TimeUnit.SECONDS)
                .statistics()
                .enabled(statisticsEnabled)
                .build();

        // Cache for individual orders: orders::uuid
        Configuration ordersCache = new ConfigurationBuilder()
                .clustering()
                .cacheMode(CacheMode.LOCAL)
                .memory()
                .maxCount(ordersMaxEntries)
                .expiration()
                .lifespan(ordersTtl, TimeUnit.SECONDS)
                .maxIdle(ordersMaxIdle, TimeUnit.SECONDS)
                .statistics()
                .enabled(statisticsEnabled)
                .build();

        // Cache for full order list: orders-list
        Configuration ordersListCache = new ConfigurationBuilder()
                .clustering()
                .cacheMode(CacheMode.LOCAL)
                .memory()
                .maxCount(ordersListMaxEntries)
                .expiration()
                .lifespan(ordersListTtl, TimeUnit.SECONDS)
                .maxIdle(ordersListMaxIdle, TimeUnit.SECONDS)
                .statistics()
                .enabled(statisticsEnabled)
                .build();

        // Create cache manager with global config
        DefaultCacheManager cacheManager = new DefaultCacheManager(globalConfig);

        // Define the default cache configuration first
        cacheManager.defineConfiguration("default", defaultCache);

        // Register named caches
        cacheManager.defineConfiguration("orders", ordersCache);
        cacheManager.defineConfiguration("orders-list", ordersListCache);

        return cacheManager;
    }

    // Expose as Spring CacheManager
    @Bean
    public CacheManager cacheManager(EmbeddedCacheManager embeddedCacheManager) {
        return new SpringEmbeddedCacheManager(embeddedCacheManager);
    }
}