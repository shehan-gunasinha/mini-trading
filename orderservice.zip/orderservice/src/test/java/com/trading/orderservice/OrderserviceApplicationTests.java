package com.trading.orderservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
